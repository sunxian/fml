package cn.com.fml.mvc.dmo;

public class TbCommission {
	private String id;
	private String createTime;
	private String updateTime;
	private String developersId;
	private String tbBuildingId;
	private String type;
	private String settlementNode;
	private String descp;
	private String amount;
	private String tsRoleId;
	private String showIndex;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getDevelopersId() {
		return developersId;
	}
	public void setDevelopersId(String developersId) {
		this.developersId = developersId;
	}
	public String getTbBuildingId() {
		return tbBuildingId;
	}
	public void setTbBuildingId(String tbBuildingId) {
		this.tbBuildingId = tbBuildingId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSettlementNode() {
		return settlementNode;
	}
	public void setSettlementNode(String settlementNode) {
		this.settlementNode = settlementNode;
	}
	public String getDescp() {
		return descp;
	}
	public void setDescp(String descp) {
		this.descp = descp;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getTsRoleId() {
		return tsRoleId;
	}
	public void setTsRoleId(String tsRoleId) {
		this.tsRoleId = tsRoleId;
	}
	public String getShowIndex() {
		return showIndex;
	}
	public void setShowIndex(String showIndex) {
		this.showIndex = showIndex;
	}
	
}

