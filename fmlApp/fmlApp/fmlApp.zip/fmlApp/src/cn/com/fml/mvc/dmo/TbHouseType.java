package cn.com.fml.mvc.dmo;

public class TbHouseType {
private String buildingId;
private String houseBanId;
private String id;
private String name;
private String livingRooms;
private String bedrooms;
private String toilets;
private String square;
private String unitPrice;
private String totalPrice;
private String isSalingFlag;
private String descp;
private String isMainFlag;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public String getLivingRooms() {
	return livingRooms;
}
public void setLivingRooms(String livingRooms) {
	this.livingRooms = livingRooms;
}
public String getBedrooms() {
	return bedrooms;
}
public void setBedrooms(String bedrooms) {
	this.bedrooms = bedrooms;
}
public String getToilets() {
	return toilets;
}
public void setToilets(String toilets) {
	this.toilets = toilets;
}
public String getSquare() {
	return square;
}
public void setSquare(String square) {
	this.square = square;
}
public String getUnitPrice() {
	return unitPrice;
}
public void setUnitPrice(String unitPrice) {
	this.unitPrice = unitPrice;
}
public String getTotalPrice() {
	return totalPrice;
}
public void setTotalPrice(String totalPrice) {
	this.totalPrice = totalPrice;
}
public String getIsSalingFlag() {
	return isSalingFlag;
}
public void setIsSalingFlag(String isSalingFlag) {
	this.isSalingFlag = isSalingFlag;
}
public String getDescp() {
	return descp;
}
public void setDescp(String descp) {
	this.descp = descp;
}
public String getIsMainFlag() {
	return isMainFlag;
}
public void setIsMainFlag(String isMainFlag) {
	this.isMainFlag = isMainFlag;
}

public String getBuildingId() {
	return buildingId;
}
public void setBuildingId(String buildingId) {
	this.buildingId = buildingId;
}
public String getHouseBanId() {
	return houseBanId;
}
public void setHouseBanId(String houseBanId) {
	this.houseBanId = houseBanId;
}

}