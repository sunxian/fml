package cn.com.fml.mvc.dao.intf;

import cn.com.fml.mvc.dmo.TsRole;

public interface TsRoleDao {

	public TsRole getTsRole(TsRole tsRole);
	
}
